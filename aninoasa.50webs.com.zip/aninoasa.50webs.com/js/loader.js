var xmlhttp;
function loadXMLDoc(url,cfunc) {
	if (window.XMLHttpRequest)
		{
		xmlhttp = new XMLHttpRequest();
		}
	else
		{
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
xmlhttp.onreadystatechange = cfunc;
xmlhttp.open("GET",url,true);
xmlhttp.send();
}
function incarcaDoc(i) {
	loadXMLDoc("content.xml",function() {
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
			{
			xmlDoc = xmlhttp.responseXML;
			cont = xmlDoc.getElementsByTagName("main")[i].childNodes[0].nodeValue;
			dreapta = xmlDoc.getElementsByTagName("right")[i].childNodes[0].nodeValue;
			document.getElementById("content").innerHTML = cont;
			document.getElementById("sidebar_container").innerHTML = dreapta;
			}
		else
			{
			k = document.createElement("img");
			k.setAttribute("src", "images/loader.gif");
			k.style.borderWidth = "0px";
			k.style.position = "fixed";
			k.style.top = "50%";
			k.style.left = "50%";
			k.style.marginLeft = "-15.5px";
			k.style.marginTop = "-15.5px";
			document.getElementById("content").appendChild(k);
			}
	});
}